function show_menu()
	love.graphics.draw(menu, 0, 0)
end
function show_menu2()
	love.graphics.draw(menu2, 0, 0)
end
function record_score()
	menu_start=true
	menu2_start=true
	high_score=score
	score = 0
end
